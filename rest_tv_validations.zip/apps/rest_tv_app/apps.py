from django.apps import AppConfig


class RestTvAppConfig(AppConfig):
    name = 'rest_tv_app'
