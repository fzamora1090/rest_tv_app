from django.db import models
from datetime import datetime
# Create your models here.
class Show(models.Model):
    title = models.CharField(max_length=50)
    network = models.CharField(max_length=50)
    
    date = models.DateField(auto_now=False, auto_now_add=False)

    description = models.TextField()

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

